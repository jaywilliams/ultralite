<p>
<a href="index.php">Back To Index</a>
</p>

<p>
WEB2BB provides a robust mail class that can use either system mail or a remote mail server. You will need to have access to the remote server for it to allow you to use it. All the basics are covered, To, From Bcc Attachments etc, or, you can simply drop in your own mailer class. The WEB2BB systems is flexible enough to allow the direct use of any third part classes.
</p>

<?php
$code='
<?php

?>
';
highlight_string($code);
?>
